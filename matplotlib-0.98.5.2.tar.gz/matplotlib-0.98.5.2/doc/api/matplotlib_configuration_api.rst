************************
matplotlib configuration
************************


:mod:`matplotlib`
=================

.. automodule:: matplotlib
   :members: rc, rcdefaults, use
   :undoc-members:
   :show-inheritance:

