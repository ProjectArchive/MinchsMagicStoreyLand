*****************
matplotlib figure
*****************


:mod:`matplotlib.figure`
========================

.. automodule:: matplotlib.figure
   :members:
   :undoc-members:
   :show-inheritance:
