***************
matplotlib axes
***************


:mod:`matplotlib.axes`
======================

.. automodule:: matplotlib.axes
   :members:
   :undoc-members:
   :show-inheritance:
 
