matplotlib animations
=====================

There are a variety of techniques you can use to create dynamic plots,
which I refer to as animations.  See the tutorial at
http://www.scipy.org/Cookbook/Matplotlib/Animations for an
introduction to the basic concepts
